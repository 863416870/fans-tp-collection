## 安装
 npm install
## 启动
npm run serve
## 打包
npm run build
## 可视化界面
vue ui

2019年3月20日16:15:09

配置多个代理跨域


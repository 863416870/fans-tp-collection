<template>
    <div>
      <div class="amap" ref='amap' style="height: 300px"></div>
    </div>
</template>

<script>
import { mapState } from 'vuex'
import AMap from 'AMap' // 引入高德地图
import { listAssign } from '_utils/tools'
export default {
  name: 'vue-amap',
  props: {},
  components: {
  },
  data () {
    return {
      address: {
        province: null,
        city: null,
        district: null,
        lat: null,
        lng: null
      }
    }
  },
  mounted () {
    this.map = new AMap.Map(this.$refs.amap, {
      resizeEnable: true
    })
    this.getLocation()
  },
  computed: {
    ...mapState(['token'])
  },
  methods: {
    getLocation () {
      const self = this
      this.map.plugin('AMap.Geolocation', () => {
        const geolocation = new AMap.Geolocation({
          // 是否使用高精度定位，默认：true
          enableHighAccuracy: true,
          // 设置定位超时时间，默认：无穷大
          timeout: 10000
        })
        geolocation.getCurrentPosition()
        AMap.event.addListener(geolocation, 'complete', onComplete)
        AMap.event.addListener(geolocation, 'error', onError)
        function onComplete (data) {
          listAssign(data.addressComponent, self.address)
        }
        function onError (data) {
          console.log(data)
        }
      })
    }
  },
  filters: {}
}
</script>

<style lang="less" scoped>

</style>

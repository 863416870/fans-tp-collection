<template>
  <header  @touchmove.prevent>
    <slot name="scan"></slot>
    <!--左侧地理位置信息-->
    <slot name='location'></slot>
    <!--跳转到上级路由-->
    <a class="go-back" v-if="goBack">
      <i class="iconfont icon-xiangzuojiantou"
         @click="back">
      </i>
    </a>
    <!--搜索框可在外部更改进行复用-->
<!--    <form class="search" v-if="isSearch" >
        <router-link to="/search" class="router-item">
          <input type="text" placeholder="搜索商品关键字 ">
          <i class="iconfont icon-sousuo"></i>
          </router-link>
      </form>-->
    <span class="center ellipsis"
          v-if="headTitle">
      {{headTitle}}
    </span>
    <slot name="right"></slot>
  </header>
</template>

<script>
export default {
  props: ['headTitle', 'goBack', 'isSearch'],
  methods: {
    back () {
      this.$router.go(-1)
    }
  }
}
</script>

<style scoped lang="less">
  @import "~@/styles/mixins";
  header {
    flex: 0 0 auto;
    display: flex;
    width: 100%;
    height: 89px;
    align-items: center;
    padding: 0 20px;
    border-bottom: 3px solid #F8F8F8;
    background: #fff;
    position: relative;
    .go-back{
      width: 21px;
      height: 100%;
      display: flex;
      align-items: center;
      justify-content: center;
      .icon-xiangzuojiantou{
        font-size: 30px;
        color: #272636;
        font-weight: bold;
      }
    }
/*    form{
      margin: auto;
      position: relative;
      input{
        width: 77vw;
        height:0.59rem;
      }
      input::-webkit-input-placeholder {
        font-size: .25rem;
        font-weight: 600;
        color:#f80b64;
        padding-left: .6rem;
      }
      .icon-sousuo{
        font-size:0.28rem;
        color:#f80b64;
        .un-center;
        left: .25rem;
        top: 51%;
      }
    }*/
    .center{
      margin: auto;
      font-size: 30px;
    }
  }
</style>

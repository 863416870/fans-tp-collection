<script>
export default {
  props: [],
  data () {
    return {}
  },
  beforeCreate () {
    const { params, query } = this.$route
    const { path } = params
    this.$router.replace({ path: '/' + path, query })
  },
  render (h) {
    return h()
  },
  created () {
  },
  mounted () {
  },
  computed: {},
  watch: {},
  methods: {},
  filters: {},
  directives: {},
  components: {}
}
</script>

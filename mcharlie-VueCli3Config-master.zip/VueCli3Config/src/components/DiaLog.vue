<template>
    <div id="dialog">
      <transition name='fade'>
      <div class="mask" v-if="isShow" @click="hideShow"></div>
      </transition>
        <transition name='fade'>
        <slot name="content" v-if="isShow" ></slot>
        </transition>
    </div>
</template>
<script>
export default {
  name: 'DiaLog',
  props: {
    isShow: Boolean
  },
  methods: {
    hideShow () {
      this.$emit('hideCurrentDialog')
    }
  }
}
</script>
<style lang="less" scoped>
  #dialog{
    .mask{
      width: 100vw;
      height: 100%;
      background: rgba(0,0,0,0.5);
      position: fixed;
      top: 0;
      left: 0;
      z-index: 99;
    }
  }
</style>

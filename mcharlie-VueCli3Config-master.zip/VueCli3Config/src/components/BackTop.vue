<template>
  <div class="back-top">
    <img src="https://china.chenglianyijia.com/assets/back_top.png"
         alt=""
         v-show='isShow'
         @click='getTop'
    >
  </div>
</template>
<script>
export default {
  name: 'backtop',
  data () {
    return {
      isShow: false
    }
  },
  mounted () {
    this.$el.parentNode.addEventListener('scroll', this.showBackTop)
  },
  methods: {
    showBackTop () {
      if (this.$el.parentNode.scrollTop > 600) {
        this.isShow = true
      } else if (this.$el.parentNode.scrollTop < 600) {
        this.isShow = false
      }
    },
    getTop () {
      let timer = setInterval(() => {
        let top = this.$el.parentNode.scrollTop
        let speed = Math.ceil(top / 5)
        this.$el.parentNode.scrollTop = top - speed
        if (top === 0) {
          clearInterval(timer)
        }
      }, 20)
    }
  }
}
</script>
<style scoped lang="less">
  div{
    img{
      display: inline-block;
      position: fixed;
      right: 12px;
      bottom: 1.86rem;
      height: 1rem;
      border-radius: 25px;
      cursor: pointer;
      transition: .3s;
      text-align: center;
      z-index: 999;
    }
  }
</style>

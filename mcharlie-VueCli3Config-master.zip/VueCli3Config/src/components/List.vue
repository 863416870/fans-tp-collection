<template functional>
  <div>
      <p v-for="(item,index) in props.items"
         :key="index"
         @click="props.itemClick(item);">
        {{ item }}
      </p>
    </div>
</template>

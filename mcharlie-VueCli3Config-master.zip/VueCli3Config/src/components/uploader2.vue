<template>
    <div class="uploader">
      <input type="file" ref="file" accept="image/*" @change="uploadFile($event)" v-if="!isToRender">
      <div class="img-wrapper" v-for="(item,index) of files" :key="index">
        <img :src="item.src" alt="">
        <span @click="remove(index)">删除</span>
      </div>
    </div>
</template>

<script>
export default {
  name: '图片上传',
  data () {
    return {
      files: [],
      isToRender: false
    }
  },
  methods: {
    /**
           * 开始文件上传
           */
    uploadFile () {
      // 获取上传文件信息
      const list = this.$refs.file.files
      for (let i = 0; i < list.length; i++) {
        if (this.verificationPicFile(list[i])) {
          if (!this.isContain(list[i])) {
            const item = {
              name: list[i].name,
              size: list[i].size,
              file: list[i]
            }
            this.html5Reader(list[i], item)
            this.files.push(item)
          } else {
            this.$toast('图片上传重复')
          }
        } else {

        }
      }
      this.$refs.file.value = ''
    },
    /**
           * 读取文件里信息
           */
    html5Reader (files, item) {
      const reader = new FileReader()
      reader.onload = (e) => {
        const result = e.target.result
        const img = new Image()
        img.src = result
        img.onload = () => {
          this.$set(item, 'src', this.compress(img, 0.3))
        }
      }
      reader.readAsDataURL(files)
    },
    /**
           * 图片大小检验
           */
    verificationPicFile (file) {
      const fileMaxSize = 5120// 限制上传文件大小限制 5120字节
      let curFileSize = (file.size) / 1024 // 当前上传图大小
      if (curFileSize > fileMaxSize) {
        this.$toast('文件大小不能大于5M')
        this.isToRender = true
        setTimeout(() => { this.isToRender = false }, 1) // 如果文件过大重新渲染input
        return false
      } else {
        return true
      }
    },
    /**
           * 图片压缩处理
           */
    compress (img, size) {
      const canvas = document.createElement('canvas')
      const ctx = canvas.getContext('2d')
      const width = img.width
      const height = img.height
      canvas.width = width
      canvas.height = height
      ctx.fillStyle = '#fff'
      ctx.fillRect(0, 0, canvas.width, canvas.height)
      ctx.drawImage(img, 0, 0, width, height)
      let compressData = canvas.toDataURL('image/jpeg', size)
      return compressData
    },
    /**
           * 文件同名校验
           * @param file
           * @returns {number | never | bigint | T | T | *}
           */
    isContain (file) {
      return this.files.find((item) => item.name === file.name && item.size === file.size)
    },
    /**
           * 删除图片
           * @param index
           */
    remove (index) {
      this.files.splice(index, 1)
    }
  }
}
</script>

<style lang="less" scoped>
  .uploader{
    input{
    }
    img{
      width: 3rem;
      height: 3rem;
      border: 1px solid red;
    }
  }
</style>

<template>
    <nav>
      <div class="item"
            v-for="(item,index) of navData"
            :key="index"
          >
        <router-link  :to="{path:`/home/index/${item.type}?id=100004`}"  replace >
          {{item.name}}
        </router-link>
      </div>
    </nav>
</template>

<script>
export default {
  name: 'Nav',
  props: {
    navData: Array
  }
}
</script>

<style lang="less" scoped>
  nav {
    width: 100%;
    height: 100px;
    display: flex;
    background: #ffffff;
    justify-content: space-between;
    position: relative;
    flex: 0 0 auto;
    .item {
      width: 20vw;
      text-align: center;
      line-height: 0.86rem;
      display: flex;
      justify-content: center;
      a{
        width: 100%;
        display: block;
        position: relative;
        &.router-link-active{
          color: #ff1919;
          border-bottom: 3px solid  #ff1919;
        }
      }
    }
  }
</style>

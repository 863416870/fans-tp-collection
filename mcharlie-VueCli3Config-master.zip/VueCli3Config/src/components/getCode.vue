<template>
  <div class="get_code">
    <span @click="getCode">
    {{msg}}
    </span>
  </div>
</template>
<script>
export default {
  data () {
    return {
      msg: '获取验证码',
      count: 60
    }
  },
  methods: {
    getCode () {
      let interval = {}
      if (this.msg === '获取验证码') {
        this.$emit('getCode', true)
        this.msg = this.count + '秒后重新发送'
        this.count--
        interval = setInterval(() => {
          if (this.count === 0) {
            clearInterval(interval)
            this.msg = '获取验证码'
            this.count = 60
            return true
          } else {
            this.msg = this.count + '秒后重新发送'
            this.count--
            return false
          }
        }, 1000)
      }
    }
  }
}
</script>

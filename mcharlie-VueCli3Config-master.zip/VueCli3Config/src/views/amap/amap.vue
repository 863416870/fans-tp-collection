<template>
    <div class="amap">
      <amaps/>
    </div>
</template>

<script>

export default {
  name: 'amap',
  props: {},
  data () {
    return {}
  },
  created () {
  },
  mounted () {
  },
  watch: {},
  methods: {},
  filters: {}
}
</script>

<style lang="less" scoped>

</style>

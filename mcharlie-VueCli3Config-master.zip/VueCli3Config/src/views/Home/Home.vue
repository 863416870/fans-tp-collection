<template>
  <div class="home">
    <head-top headTitle="Home" :goBack="true"/>
    <h3>常用组件</h3>
    <!--页面重载-->
    <H4>页面重载</H4>
    <van-button type="primary" @click="redirect">页面重载</van-button>
    <!--上传组件-->
    <H4>图片上传</H4>
    <uploader/>
    <H4>获取验证码</H4>
    <getCode @getCode="getCode"/>
    <H4>回顶</H4>


    <BackTop/>

    <!--    <List
          :items="['Wonderwoman', 'Ironman']"
          :item-click="item => (clicked = item)"
        />
        <p>Clicked hero: {{ clicked }}</p>-->
  </div>
</template>
<script>
import { getPhoneCode } from '@/api'
import { Button } from 'vant'
export default {
  name: 'home',
  components: {
    [Button.name]: Button
  },
  data () {
    return {
      clicked: ''
    }
  },
  methods: {
    async getCode (params) {
      if (params) await getPhoneCode({ phone: '15296708547' })
    },
    debug (msg) {
      console.log(msg)
    },
    redirect () {
      // 手动重定向页面到 '/redirect' 页面
      const { fullPath } = this.$route
      console.log(fullPath)
      this.$router.replace({
        path: '/redirect' + fullPath
      })
    }
  }
}
</script>
<style lang="less" scoped>
  .home {
    display: flex;
    flex-direction: column;
    height: 100%;
    overflow: auto;
    -webkit-overflow-scrolling: touch;

    section {
      flex: 1;
      overflow: auto;
    }
  }
</style>

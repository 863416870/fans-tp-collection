<template>
  <div class="items">
    <div
      class="listitem"
      v-for="(item,index) of shoplist"
      :key="index"
    >
      <img :src="item.pic" alt="" class="shopimg">
      <p class="name" style="-webkit-box-orient: vertical;">{{item.name}}</p>
      <p class="price">￥{{item.price-item.packetMoney|formatPrice}}+{{item.packetMoney}}零钱</p>
      <p class="oldprice">
        原价:￥
        <span style="text-decoration: line-through;">{{item.oldprice}}元</span>
        <span @click.stop="shareGoods(item.pic,item.name,item.goodsDepict,item.id,item.price,item.oldprice,item.packetMoney)">分享</span>
      </p>
    </div>
  </div>
</template>

<script>
import { getGoodsbyType } from '@/api/modules/home'
export default {
  name: 'test',
  props: {},
  data () {
    return {
      type: this.$route.params.type,
      shoplist: []
    }
  },
  watch: {
    '$route' (newVal) {
      this.type = newVal.params.type
      this.getGoodsbyType(this.type)
    }
  },
  async created () {
    this.getGoodsbyType(this.type)
  },
  methods: {
    async getGoodsbyType (type) {
      const res = await getGoodsbyType({
        id: 100004,
        type: type
      })
      console.log(res)
      this.shoplist = res.data.map(item => {
        let json = {
          id: item.goodsId,
          pic: item.goodsBanner,
          name: item.goodsName,
          oldprice: item.originalPrice,
          price: item.presentPrice,
          packetMoney: item.pocketMoney,
          goodsDepict: item.goodsDepict
        }
        return json
      })
    }
  },
  filters: {}
}
</script>

<style lang="less" scoped>
  .items{
    width: 94vw;
    margin: 0 auto;
    display: flex;
    justify-content: space-between;
    flex-wrap: wrap;
    height: 100%;
  }
  .shopbanner{
    width: 100vw;
    height: 2.03rem;
    margin: 0.2rem auto;
  }
  .shopimg{
    width: 100%;
    height: 3.3rem;
  }
  .scrollbox{
    display: flex;
    justify-content: space-between;
    flex-wrap: wrap;
  }
  .listitem{
    width: 44.2vw;
    background: white;
    margin-top: 0.24rem;
    min-height: 3.3rem;
  }
  .classifylist{
    height: 100%;
    overflow: hidden;
  }
  .quxiao {
    width: 100%;
    height: 0.74rem;
    background: #fb879f;
    color: white;
    text-align: center;
    line-height: 0.74rem;
  }

</style>

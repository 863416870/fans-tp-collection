<template>
  <div class="home">
    <head-top headTitle="Home" :goBack="true"/>
    <Nav :navData="navData"/>
    <section >
      <cube-scroll ref='scroll'>
        <router-view/>
      </cube-scroll>
    </section>
    <footer>
    </footer>
  </div>
</template>
<script>
import { getGoodsClassList } from '@/api/modules/home.js'
export default {
  name: 'home',
  data () {
    return {
      navData: []
    }
  },
  async created () {
    const res = await getGoodsClassList({ 'type': '1' })
    try {
      const { data } = res
      this.navData = data.map((value) => {
        const obj = {}
        obj.name = value.name
        obj.type = value.id
        return obj
      })
      const { type } = this.navData[0]
      console.log(type)
      this.$router.replace(`/home/index/${type}?id=100004`)
    } catch (e) {
      console.log(e)
    }
  }
}
</script>
<style lang="less" scoped>
  .home{
    display: flex;
    flex-direction: column;
    height: 100%;
    overflow: auto;
    -webkit-overflow-scrolling: touch;
    section{
      flex: 1;
      overflow: auto;
    }
  }
</style>

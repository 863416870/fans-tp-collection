<template>
    <div class="Me">
        <!--<head-top headTitle="个人中心" go-back="true"/>-->
      <span @click="$router.push('/me/add-address')">添加收货地址</span>
    </div>
</template>
<style lang="less" scoped>

</style>

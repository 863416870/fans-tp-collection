<template>
    <div id="add-address">
      <head-top headTitle="新增收货地址" go-back="true"/>
      <van-address-edit
        :area-list="areaList"
        show-set-default
        show-search-result
        :search-result="searchResult"
        @save="onSave"
      />
    </div>
</template>

<script>
import areaList from '../../../../assets/js/area'
import { AddressEdit } from 'vant'
export default {
  computed: {
  },
  data () {
    return {
      areaList,
      searchResult: []
    }
  },
  components: {
    [AddressEdit.name]: AddressEdit
  },
  methods: {
    onSave (content) {
      let params = {
        token: this.token,
        addressid: '',
        name: content.name,
        phone: content.tel,
        province: content.province,
        city: content.city,
        county: content.county,
        detail: content.addressDetail,
        status: content.isDefault === true ? '1' : '0',
        code: content.areaCode
      }
    }
  }
}
</script>

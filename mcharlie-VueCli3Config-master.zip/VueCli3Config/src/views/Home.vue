<template>
  <div>
    <h4>基于Vue.2X的html5上传图片组件asd </h4>
    <div style="width: 502px;">
      <uploader :src="'/api/imgs'"></uploader>
    </div>
  </div>
</template>
<script>
import uploader from '@/components/uploader.vue'
export default {
  name: 'home',
  created () {

  },
  methods: {
  }
}
</script>

<template>
    <div>
      <router-view/>
    </div>
</template>

<script>
export default {
  props: [],
  data () {
    return {}
  },
  created () {
  },
  mounted () {
  },
  computed: {},
  watch: {},
  methods: {},
  filters: {},
  directives: {},
  components: {}
}
</script>

<style scoped lang="less">

</style>

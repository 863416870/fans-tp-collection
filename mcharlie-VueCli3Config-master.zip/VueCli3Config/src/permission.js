import router from './router'
// const whiteList = [''] // 路由白名单
router.beforeEach((to, from, next) => {
  if (to.path === '/') {
    next({ path: '/home' })
  } else {
    next()
  }
})

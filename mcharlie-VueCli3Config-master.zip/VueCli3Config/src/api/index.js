import { get, post } from '../utils/fetch'
export const getPhoneCode = (params) => post('/webservice/clyjUser/getCode', params)

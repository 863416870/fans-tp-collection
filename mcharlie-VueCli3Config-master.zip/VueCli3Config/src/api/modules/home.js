import { get, post } from '@/utils/fetch'
// 商品一级分类
export const getGoodsClassList = (params) => post('webservice/goodsClass/getGoodsClassList', params)
export const getGoodsbyType = (params) => post('webservice/clyjGoodsHomepage/getGoodsBytype', params)

import wx from 'weixin-js-sdk'
import { get } from '@/api/fetch'
import { Base64 } from 'js-base64'
const href = Base64.encode(location.href.split('#')[0]) // domain
class Wxjsdk {
  static init () {
    return new Promise((resolve, reject) => {
      get(`${location.origin}/clyjUser/wxLogin?href=${href}`).then((res) => {
        wx.config({
          debug: true, // 开启调试模式,调用的所有api的返回值会在客户端alert出来，若要查看传入的参数，可以在pc端打开，参数信息会通过log打出，仅在pc端时才会打印。
          appId: res.appid, // 必填，公众号的唯一标识
          timestamp: res.timestamp, // 必填，生成签名的时间戳
          nonceStr: res.nonceStr, // 必填，生成签名的随机串
          signature: res.signature, // 必填，签名，见附录1
          jsApiList: ['getLocation',
            'onMenuShareTimeline',
            'onMenuShareAppMessage',
            'scanQRCode',
            'startRecord',
            'onVoiceRecordEnd',
            'stopRecord',
            'playVoice'] // 必填，需要使用的JS接口列表，所有JS接口列表见附录2
        })
        wx.ready(function () {
          resolve()
        })
      })
    })
  }
  // 微信分享
  static share (title, desc, link, imgUrl) {
    return new Promise(resolve => {
      this.init().then(() => {
        wx.updateAppMessageShareData({
          title: title, // 分享标题
          desc: desc, // 分享描述
          link: link, // 分享链接，该链接域名或路径必须与当前页面对应的公众号JS安全域名一致
          imgUrl: imgUrl, // 分享图标
          success: function (res) {
            resolve(res)
          }
        })
      })
    })
  }
  // 微信扫一扫
  static scan () {
    return new Promise(resolve => {
      this.init().then(() => {
        wx.scanQRCode({
          needResult: 0, // 默认为0，扫描结果由微信处理，1则直接返回扫描结果，
          scanType: ['qrCode', 'barCode'], // 可以指定扫二维码还是一维码，默认二者都有
          success: function (res) {
            var result = res.resultStr // 当needResult 为 1 时，扫码返回的结果
            resolve(result)
          }
        })
      })
    })
  }

  /**
   * 微信支付
   */
  static pay (data) {
    return new Promise(resolve => {
      wx.chooseWXPay({
        timestamp: 0, // 支付签名时间戳，注意微信jssdk中的所有使用timestamp字段均为小写。但最新版的支付后台生成签名使用的timeStamp字段名需大写其中的S字符
        nonceStr: '', // 支付签名随机串，不长于 32 位
        package: '', // 统一支付接口返回的prepay_id参数值，提交格式如：prepay_id=\*\*\*）
        signType: '', // 签名方式，默认为'SHA1'，使用新版支付需传入'MD5'
        paySign: '', // 支付签名
        success: function (res) {
          resolve(res)
        }
      })
    })
  }

  /*  /!**
   * 获取地理位置信息
   *!/
  static getLocation () {
    return new Promise(resolve => {
      this.init().then(() => {
        let result = false
        wx.getLocation({
          type: 'wgs84', // 默认为wgs84的gps坐标，如果要返回直接给openLocation用的火星坐标，可传入'gcj02'
          success: function (res) {
            result = {
              lat: res.latitude,
              lon: res.longitude
            }
            resolve(result)
          }
        })
      })
    })
  } */
}
export default Wxjsdk

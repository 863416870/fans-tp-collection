class Storage {
  static saveData (KEY, data) {
    window.localStorage.setItem(KEY, JSON.stringify(data))
  }
  static readData (KEY) {
    return JSON.parse(window.localStorage.getItem(KEY) || '[]')
  }
  static removeData (KEY) {
    if (window.localStorage) {
      localStorage.removeItem(KEY)
    }
  }
}
export default Storage

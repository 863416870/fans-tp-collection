/**
 * 环境注入
 */
export default (Vue) => {
  // 如果是非线上环境，不加载 VConsole
  if (process.env.NODE_ENV !== 'production') {
    /*    var VConsole = require('@/assets/js/vconsole.min.js')
    var vConsole = new VConsole() */
    Vue.config.performance = true
  }
}

export function tel (value) {
  const reg = /^1\d{10}$/
  if (value === '') {
    return false
  } else {
    return reg.test(value.trim())
  }
}
export function pwd (value) {
  const reg = /^(?![0-9]+$)(?![a-zA-Z]+$)[0-9A-Za-z]{8,16}$/
  if (value === '') {
    return false
  } else {
    return reg.test(value.trim())
  }
}
/**
 * @returns {boolean}
 * 验证银行卡一般为15位到19位，第一位不能为0
 */
export function card (value) {
  const reg = /^([1-9]{1})(\d{14}|\d{18})$/
  if (value === '') {
    return false
  } else {
    return reg.test(value.trim())
  }
}

export function username (value) {
  const reg = /^[\u4E00-\u9FA5\uf900-\ufa2d]{2,4}$/
  if (value === '') {
    return false
  } else {
    return reg.test(value.trim())
  }
}

import { getToken } from '@/utils/auth'     // token
import store from '@/store'
const axios = require('axios')  //
const qs = require('qs')
// 请求环境切换
const reqUrl = process.env.NODE_ENV === 'production' ? 'http://china.chenglianyijia.com' : ' '
const service = axios.create({
  baseURL: reqUrl,
  withCredentials: true
  // timeout: 10000// 请求超时时间
})

// request 拦截器
service.interceptors.request.use(config => {
  if (store.getters.token) {
    config.headers['X-Token'] = getToken()
  }
  let data = JSON.stringify(config.data)
  if (config.method === 'post') {
    data = qs.stringify(config.data)
  }
  return config
}, error => {
  Promise.reject(error)
})

// response拦截器
service.interceptors.response.use(
  response => response,
  error => {
    const errMsg = error.toString()
    const code = errMsg.substr(errMsg.indexOf('code') + 5)
    if (code === '500' || code === '400' || code === '502') {
      // Toast('服务器错误')
    }
    if (error.code === 'ECONNABORTED' && error.message.indexOf('timeout') !== -1) {
      // Toast('请求超时')
    }
    // 重定向错误页面
    return Promise.reject(error)
  }
)
const fetch = (method, url, data = {}, config) => {
  config = config || {}
  config.method = method
  config.url = url
  method.toLocaleLowerCase() === 'get' ? config['params'] = data : config['data'] = data
  return service(config).then(function (res) {
    return res.data
  })
}

const get = (url, data, config) => {
  return fetch('get', url, data, config)
}

const post = (url, data, config) => {
  return fetch('post', url, data, config)
}

export { get, post }

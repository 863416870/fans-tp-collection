import router from '../router'
const judgeBrowserVersions = () => {
  const u = navigator.userAgent; const app = navigator.appVersion
  return {// 移动终端浏览器版本信息
    trident: u.indexOf('Trident') > -1, // IE内核
    presto: u.indexOf('Presto') > -1, // opera内核
    webKit: u.indexOf('AppleWebKit') > -1, // 苹果、谷歌内核
    gecko: u.indexOf('Gecko') > -1 && u.indexOf('KHTML') == -1, // 火狐内核
    mobile: !!u.match(/AppleWebKit.*Mobile.*/) ||
      !!u.match(/AppleWebKit/), // 是否为移动终端
    ios: !!u.match(/\(i[^;]+;( U;)? CPU.+Mac OS X/), // ios终端
    android: u.indexOf('Android') > -1 || u.indexOf('Linux') > -1, // android终端或者uc浏览器
    iPhone: u.indexOf('iPhone') > -1 || u.indexOf('Mac') > -1, // 是否为iPhone或者QQHD浏览器
    iPad: u.indexOf('iPad') > -1, // 是否iPad
    webApp: u.indexOf('Safari') == -1, // 是否web应该程序，没有头部与底部
    google: u.indexOf('Chrome') > -1,
    weChat: (u.indexOf('MicroMessenger') > -1 || u.indexOf('micromessenger') > -1) && u.indexOf('wxwork') === -1
  }
}

// 不同站店跳转
const loseToken = () => {
  if (judgeBrowserVersions().weChat) {
    window.location.href = `${location.origin}/webservice/clyjUser/wxLogin?type=null&userid=null&tradeNo=null&inviteCode=null`
  } else {
    router.push('/login')
  }
}

// 解决js计算精度问题
/**
 *
 * @param number:要格式化的数字
 * @param decimals:保留几位小数
 * @param dec_point:小数点符号
 * @param thousands_sep:千分位符号
 * @param roundtag:舍入参数，默认 "ceil" 向上取,"floor"向下取,"round" 四舍五入
 */
const number_format = (number, decimals, dec_point, thousands_sep, roundtag) => {
  number = (number + '').replace(/[^0-9+-Ee.]/g, '')
  roundtag = roundtag || 'ceil' // "ceil","floor","round"
  var n = !isFinite(+number) ? 0 : +number
  var prec = !isFinite(+decimals) ? 0 : Math.abs(decimals)
  var sep = (typeof thousands_sep === 'undefined') ? ',' : thousands_sep
  var dec = (typeof dec_point === 'undefined') ? '.' : dec_point
  var s = ''
  var toFixedFix = function (n, prec) {
    var k = Math.pow(10, prec)
    console.log()

    return '' + parseFloat(Math[roundtag](parseFloat((n * k).toFixed(prec * 2))).toFixed(prec * 2)) / k
  }
  s = (prec ? toFixedFix(n, prec) : '' + Math.round(n)).split('.')
  var re = /(-?\d+)(\d{3})/
  while (re.test(s[0])) {
    s[0] = s[0].replace(re, '$1' + sep + '$2')
  }

  if ((s[1] || '').length < prec) {
    s[1] = s[1] || ''
    s[1] += new Array(prec - s[1].length + 1).join('0')
  }
  return s.join(dec)
}
const moneyToNumValue = (val) => {
  const num = val.trim()
  let ss = num.toString()
  if (ss.length === 0) {
    return '0'
  }
  return ss.replace(/,/g, '')
}

const pushHistory = () => {
  let state = {
    title: '',
    url: ''
  }
  window.history.pushState(state, state.title, state.url)
}

/**
 * 对象赋值
 * @param arrA
 * @param arrB
 */
const listAssign = (arrA, arrB) => Object.keys(arrA).forEach(key => { arrA[key] = arrB[key] || arrA[key] })

export { judgeBrowserVersions, loseToken, number_format, moneyToNumValue, pushHistory, listAssign }


/**
 *
 * @param img base64
 * @param size 压缩比     0.3
 * @returns {string}
 */
function compress(img, size){
  const canvas = document.createElement('canvas')
  const ctx = canvas.getContext('2d')
  const width = img.width
  const height = img.height
  canvas.width = width
  canvas.height = height
  ctx.fillStyle = '#fff'
  ctx.fillRect(0, 0, canvas.width, canvas.height)
  ctx.drawImage(img, 0, 0, width, height)
  let compressData = canvas.toDataURL('image/jpeg', size)
  return compressData
}

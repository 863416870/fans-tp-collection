import Vue from 'vue'
// const Vue = require('vue')
import App from './App.vue'
import router from './router'
// 样式重置
import '@/styles/index.less'
import 'amfe-flexible' // 手淘适配
import { Toast } from 'vant'
import './permission' // permission control
import * as filters from './filters' // global filters
// 公共方法
import entryConfig from './utils/entryConfig'
// 加载公共组件
import '@/components/global.js'
// 移动端点击300秒延迟
import FastClick from 'fastclick'
Vue.prototype.$toast = Toast
FastClick.attach(document.body) // 一般直接放在这个位置
// 上传测试
// 公共filters
// register global utility filters
Object.keys(filters).forEach(key => {
  Vue.filter(key, filters[key])
})
entryConfig(Vue)
Vue.config.productionTip = false
new Vue({
  router,
  render: h => h(App)
}).$mount('#app')

import { number_format } from '@/utils/tools'

/**
 * 现金显示过滤
 * @param price
 * @returns {*}
 */
const formatPrice = (price) => {
  return number_format(price, 2, '.', ',', 'floor')
}
/**
 * 格式化手机号码
 * @param value
 * @returns {*|void|string|never}
 */
const formatPhone = (value) => {
  const reg = /(\d{3})\d{4}(\d{4})/
  return value.replace(reg, '$1****$2')
}

/**
 * 运费格式化
 * @param value
 * @returns {*}
 */
const formatePostFree = (value) => {
  if (value === 0) {
    return '包邮'
  } else {
    return value
  }
}

export {
  formatPrice,
  formatPhone,
  formatePostFree
}

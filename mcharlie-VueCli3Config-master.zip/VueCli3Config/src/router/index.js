import Vue from 'vue'
import Router from 'vue-router'
import homeRouter from './modules/home'
import meRouter from './modules/me'
const Layout = resolve => { require.ensure(['@/Layout/index.vue'], () => { resolve(require('@/Layout/index.vue')) }) }
Vue.use(Router)

export const Routes = [
  homeRouter,
  meRouter,
  {
    path: '/',
    component: Layout,
    children: [{
      path: '/amap',
      name: 'amap',
      component: () => import('@/views/amap/amap'),
      meta: {
        showFooter: true
      }
    }]
  },
  {
    // 重定向  页面自动刷新
    path: '/redirect',
    component: Layout,
    hidden: true,
    children: [
      {
        path: '/redirect/:path*',
        component: () => import('@/views/redirect/index')
      }
    ]
  }
]

const createRouter = () => new Router({
  // mode: 'history', // require service support
  scrollBehavior: () => ({ y: 0 }),
  routes: Routes
})
const router = createRouter()
export default router

const Layout = resolve => {
  require.ensure(['@/Layout/index.vue'], () => {
    resolve(require('@/Layout/index.vue'))
  })
}
const homeRouter = {
  path: '/',
  component: Layout,
  children: [{
    name: 'home',
    path: '/home',
    component: () => import('@/views/Home/Home'),
    meta: {
      showFooter: true
    }
  }]
}
export default homeRouter

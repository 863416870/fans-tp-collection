const Layout = resolve => {
  require.ensure(['@/Layout/index.vue'], () => {
    resolve(require('@/Layout/index.vue'))
  })
}
const me = resolve => {
  require.ensure(['@/views/Me/Me.vue'], () => {
    resolve(require('@/views/Me/Me.vue'))
  })
}
const meRouter = {
  path: '/me',
  component: Layout,
  children: [{
    path: '/me',
    name: 'me',
    component: () => import('@/views/Me/Me'),
    meta: {
      showFooter: true
    }
  }, {
    path: 'add-address',
    name: 'addAddress',
    component: () => import('@/views/Me/Address/AddAdress.vue')
  }]
}
export default meRouter

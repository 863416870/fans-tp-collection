<template>
  <div class="footer-guide">
    <router-link v-for="(item,index) of tabBar" :to="{name:item.name}" :key="index">
      {{item.label}}
    </router-link>
  </div>
</template>

<script>
export default {
  data () {
    return {
      tabBar: [{
        label: '首页',
        name: 'home'
      },
      {
        label: '个人中心',
        name: 'me'
      },
      {
        label: 'amap',
        name: 'amap'
      }
      ]
    }
  }
}
</script>

<style lang="less" scoped>
  .footer-guide {
    position: fixed;
    left: 0;
    right: 0;
    bottom: 0;
    height: 1rem;
    display: flex;
    align-items: center;
    border: 1px solid red;

    a {
      flex: 1;
      text-align: center;
    }
  }
</style>

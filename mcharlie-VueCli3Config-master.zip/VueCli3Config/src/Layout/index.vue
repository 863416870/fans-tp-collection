<template>
  <main>
    <transition name="router-fade" mode="out-in">
      <keep-alive :include="include">
        <router-view v-if="$route.meta.keepAlive"/>
      </keep-alive>
    </transition>
    <transition name="router-fade" mode="out-in">
      <router-view :key="$route.path"
                   v-if="!$route.meta.keepAlive"/>
    </transition>
    <footer-guide v-if="$route.meta.showFooter"/>
  </main>
</template>
<script>
import FooterGuide from './components/FooterGuide'
export default {
  name: 'layout',
  created () {
  },
  data: () => ({
    include: []
  }),
  watch: {
    $route (to, from) {
      if (to.meta.keepAlive) {
        !this.include.includes(to.name) && this.include.push(to.name)
      }
      if (from.meta.keepAlive && to.meta.deepth < from.meta.deepth) {
        let index = this.include.indexOf(from.name)
        index !== -1 && this.include.splice(index, 1)
      }
    }
  },
  components: {
    FooterGuide
  }
}
</script>
<style lang="less">
  .router-fade-enter-active, .router-fade-leave-active {
    transition: opacity .2s;
  }
  .router-fade-enter, .router-fade-leave-active {
    opacity: 0;
  }
  .tabbar{
    position: fixed;
    left: 0;
    bottom:0;
    z-index: 99;
  }
</style>

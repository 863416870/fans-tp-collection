const path = require('path')
const CompressionWebpackPlugin = require('compression-webpack-plugin')
const productionGzipExtensions = ['js', 'css']
const isPro = process.env.NODE_ENV === 'production' // 是否为生产环境
const resolve = dir => {
  return path.join(__dirname, dir)
}

module.exports = {
  // 给整个项目添加二级目录
  publicPath: '',
  // 打包输出的文件夹 默认是dist
  outputDir: 'dist',

  // 生成环境下快速定位错误信息
  productionSourceMap: false,
  devServer: { // 配置webpack-dev-server行为
    open: true, // 自动打开浏览器
    https: false, // 使用https服务
    host: '192.168.1.104',
    port: '8107',
    proxy: {
      '/': {
        ws: false, // proxy websockets
        target: 'https://china.chenglianyijia.com/',
        changeOrigin: true,
        pathRewrite: { '^/': '' } // 代理重写
      }
    }
  },
  /**
   * vue-cli 内部webpack配置
   * @param config
   */
  chainWebpack: config => {
    // 设置快捷目录别名
    config.resolve.alias
      .set('@', resolve('src'))
      .set('_utils', resolve('src/utils'))
      .set('_com', resolve('src/components'))
      .set('_assets', resolve('src/assets'))
    if (isPro) { // 解决vue-cli3脚手架创建的项目压缩html 干掉<!-- shell -->导致骨架屏不生效
      config.plugin('html').tap(opts => {
        opts[0].minify.removeComments = false
        return opts
      })
    }
  },
  lintOnSave: false,
  css: {
    // 是否使用css分离插件 ExtractTextPlugin
    extract: true,
    // 开启 CSS source maps?
    sourceMap: false,
    // css预设器配置项
    // 启用 CSS modules for all css / pre-processor files.
    modules: false,
    loaderOptions: {
      postcss: {
        plugins: [
          require('postcss-px2rem-exclude')({
            remUnit: 75,
            exclude: /node_modules|folder_name/i
          })
        ]
      },
      stylus: {
        'resolve url': true,
        'import': [
        ]
      }
    }
  },

  configureWebpack: {
    externals: {
      'AMap': 'AMap', // 高德地图配置
      'vue': 'Vue'
    }
    /*    plugins: [
      new CompressionWebpackPlugin({
        filename: '[path].gz[query]',
        algorithm: 'gzip',
        test: /\.js$|\.html$|\.json$|\.css/,
        threshold: 0, // 只有大小大于该值的资源会被处理
        minRatio: 0.8, // 只有压缩率小于这个值的资源才会被处理
        deleteOriginalAssets: true // 删除原文件
      })
    ] */
  }
}
